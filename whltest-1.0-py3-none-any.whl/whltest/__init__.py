def function_init():
    print('Successfully Imported Init.py')

def print_age(age):
    print(f'I am {age} years old')